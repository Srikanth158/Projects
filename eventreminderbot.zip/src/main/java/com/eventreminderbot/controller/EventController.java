package com.eventreminderbot.controller;

import com.eventreminderbot.model.Event;
import com.eventreminderbot.service.EventService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = "*")
public class EventController {

    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping
    public List<Event> getEvents() {
        return eventService.getAllEvents();
    }

    @PostMapping
    public Event createEvent(@RequestBody Event event) {
        return eventService.saveEvent(event);
    }

    @PutMapping("/{id}")
    public Event update(@PathVariable Long id, @RequestBody Event updated) {
        return eventService.getEventById(id)
                .map(e -> {
                    e.setTitle(updated.getTitle());
                    e.setDescription(updated.getDescription());
                    e.setEventDateTime(updated.getEventDateTime());
                    return eventService.saveEvent(e);
                })
                .orElseThrow(() -> new RuntimeException("Event not found: " + id));
    }

    @DeleteMapping("/{id}")
    public void deleteEvent(@PathVariable Long id) {
        eventService.deleteEvent(id);
    }

    // DB sanity check: creates 1 sample event and returns count
    @GetMapping("/dbtest")
    public String dbTest() {
        Event sample = new Event("Sample Event", "Created by /api/events/dbtest", LocalDateTime.now().plusDays(1));
        eventService.saveEvent(sample);
        int count = eventService.getAllEvents().size();
        return "DB Connection OK! Total events: " + count;
    }
}
