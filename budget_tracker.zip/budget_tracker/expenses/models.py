from django.db import models

class Expense(models.Model):
    CATEGORY_CHOICES = [
        ('Food & Beverage', 'Food & Beverage'),
        ('Rent', 'Rent'),
        ('Transport', 'Transport'),
        ('Relaxing', 'Relaxing'),
        ('Shopping', 'Shopping'),
        ('Debts', 'Debts'),
    ]

    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField()

    def __str__(self):
        return f"{self.category} - ${self.amount} on {self.date}"
