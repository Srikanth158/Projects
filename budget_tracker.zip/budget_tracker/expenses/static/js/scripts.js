document.addEventListener("DOMContentLoaded", function () {
  // Function to get the CSRF token from the form
  function getCsrfToken() {
    return document.querySelector("[name=csrfmiddlewaretoken]").value;
  }

  // Function to fetch expenses from the server and update the table
  function fetchExpenses() {
    fetch("/api/expenses/")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        console.log("Fetched expenses:", data); // Debugging line
        const expensesTableBody = document.getElementById(
          "expenses-table-body"
        );
        expensesTableBody.innerHTML = ""; // Clear existing rows
        data.forEach((expense) => {
          addExpenseToTable(expense);
        });
        updateTotalAmount(data); // Pass the data to updateTotalAmount
      })
      .catch((error) => console.error("Error:", error));
  }

  // Function to add an expense to the table
  function addExpenseToTable(expense) {
    const expensesTableBody = document.getElementById("expenses-table-body");
    const newRow = expensesTableBody.insertRow();
    const categoryCell = newRow.insertCell();
    const amountCell = newRow.insertCell();
    const dateCell = newRow.insertCell();
    const deleteCell = newRow.insertCell();
    const deleteBtn = document.createElement("button");

    deleteBtn.textContent = "Delete";
    deleteBtn.classList.add("delete-btn");
    deleteBtn.addEventListener("click", function () {
      fetch(`/api/expenses/${expense.id}/`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCsrfToken(), // Include CSRF token
        },
      })
        .then((response) => {
          if (response.ok) {
            expensesTableBody.removeChild(newRow);
            // Fetch and update total amount after deletion
            fetchExpenses();
          } else {
            alert("Failed to delete expense");
          }
        })
        .catch((error) => console.error("Error:", error));
    });

    categoryCell.textContent = expense.category;
    amountCell.textContent = expense.amount;
    dateCell.textContent = expense.date;
    deleteCell.appendChild(deleteBtn);
  }

  // Function to update the total amount
  function updateTotalAmount(expenses) {
    const totalAmountCell = document.getElementById("total-amount");
    let totalAmount = 0;
    expenses.forEach((expense) => {
      totalAmount += parseFloat(expense.amount); // Ensure amount is treated as a number
    });
    console.log("Calculated total amount:", totalAmount); // Debugging line
    totalAmountCell.textContent = totalAmount.toFixed(2);
  }

  // Event listener for the "Add" button
  document.getElementById("add-btn").addEventListener("click", function () {
    const category = document.getElementById("category-select").value;
    const amount = parseFloat(document.getElementById("amount-input").value);
    const date = document.getElementById("date-input").value;

    if (category === "selected" || isNaN(amount) || amount <= 0 || !date) {
      alert("Please enter valid data");
      return;
    }

    fetch("/api/expenses/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCsrfToken(), // Include CSRF token
      },
      body: JSON.stringify({ category, amount, date }),
    })
      .then((response) => response.json())
      .then((data) => {
        addExpenseToTable(data);
        // Fetch and update total amount after adding a new expense
        fetchExpenses();
      })
      .catch((error) => console.error("Error:", error));
  });

  // Fetch expenses when the page loads
  fetchExpenses();
});
