# views.py
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json
from .serializers import ExpenseSerializer
from .models import Expense
from django.shortcuts import render
@csrf_exempt
@require_http_methods(["POST"])
def create_expense(request):
    try:
        data = json.loads(request.body)
        category = data.get('category')
        amount = data.get('amount')
        date = data.get('date')

        if not category or not isinstance(amount, (int, float)) or amount <= 0 or not date:
            return JsonResponse({'error': 'Invalid data'}, status=400)

        expense = Expense.objects.create(
            category=category,
            amount=amount,
            date=date
        )
        return JsonResponse({
            'id': expense.id,
            'category': expense.category,
            'amount': expense.amount,
            'date': expense.date
        })
    except (KeyError, json.JSONDecodeError):
        return JsonResponse({'error': 'Invalid data'}, status=400)

@csrf_exempt
@require_http_methods(["DELETE"])
def delete_expense(request, expense_id):
    try:
        expense = Expense.objects.get(id=expense_id)
        expense.delete()
        return JsonResponse({'message': 'Expense deleted successfully'}, status=200)
    except Expense.DoesNotExist:
        return JsonResponse({'error': 'Expense not found'}, status=404)

@csrf_exempt
@require_http_methods(["GET", "POST"])
def expense_list(request):
    if request.method == 'GET':
        expenses = Expense.objects.all()
        serializer = ExpenseSerializer(expenses, many=True)
        return JsonResponse(serializer.data, safe=False)
    
    elif request.method == 'POST':
        import json
        data = json.loads(request.body)
        serializer = ExpenseSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

def index(request):
    return render(request, 'index.html')
