# expenses/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Serve the HTML page
    path('api/expenses/', views.expense_list, name='expenses_list'),  # Handle GET requests to list expenses
    path('api/expenses/add/', views.create_expense, name='create_expense'),  # Handle POST requests to add an expense
    path('api/expenses/<int:expense_id>/', views.delete_expense, name='delete_expense'),  # Handle DELETE requests to delete an expense
]
